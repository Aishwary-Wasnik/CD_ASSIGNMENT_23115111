# Compiler Design Project: Custom Instruction `hypot`

## Overview
This project implements a custom instruction `hypot R1 R2 R3` that computes the hypotenuse `sqrt(a^2 + b^2)` using values from registers R1 (a) and R2 (b), storing the result in R3.

## Files
- `hypot_sim.c`: Simulator for the hypot instruction.
- `test_hypot.txt`: Sample instruction input.
- `README.md`: This documentation.

## Compilation (macOS)
```bash
gcc -o hypot_sim hypot_sim.c -lm