#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

// Register file (R0 to R9)
double registers[10] = {0};

// Custom instruction: hypot R1 R2 R3
void execute_hypot(int reg_a, int reg_b, int reg_result) {
    if (reg_a < 0 || reg_a > 9 || reg_b < 0 || reg_b > 9 || reg_result < 0 || reg_result > 9) {
        printf("Error: Invalid register number\n");
        return;
    }
    double a = registers[reg_a];
    double b = registers[reg_b];
    registers[reg_result] = sqrt(a * a + b * b);
    printf("Hypotenuse (R%d = %f, R%d = %f) stored in R%d: %f\n", 
           reg_a, a, reg_b, b, reg_result, registers[reg_result]);
}

// Parse and execute an instruction
void process_instruction(const char *instr) {
    char op[10];
    int r1, r2, r3;
    if (sscanf(instr, "%s R%d R%d R%d", op, &r1, &r2, &r3) == 4) {
        if (strcmp(op, "hypot") == 0) {
            execute_hypot(r1, r2, r3);
        } else {
            printf("Unknown operation: %s\n", op);
        }
    } else {
        printf("Invalid instruction format: %s\n", instr);
    }
}

int main() {
    // Test case: a = 3, b = 4, expect hypot = 5
    registers[1] = 3.0; // R1 = 3
    registers[2] = 4.0; // R2 = 4
    printf("Initial values: R1 = %f, R2 = %f\n", registers[1], registers[2]);
    
    // Simulate instruction
    process_instruction("hypot R1 R2 R3");
    
    return 0;
}